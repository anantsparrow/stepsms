<?php

if (!defined("WHMCS"))
	die("This file cannot be accessed directly");

require_once("api.php");
$api = new stepsms();
$lists = $api->getLists();

foreach($lists as $lists){
    add_hook($lists['hook'], 1, $lists['function'], "");
}